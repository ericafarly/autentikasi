Nama: Erica Farly Putri
Nim:362358302153
Kelas:2B TRPL

1.Apa yang dimaksud dengan Laravel Sanctum?
  laravel Sanctum adalah paket autentikasi untuk Laravel yang menyediakan metode autentikasi berbasis token untuk aplikasi web, aplikasi mobile, dan API, memungkinkan penggunaan token personal access tanpa kerumitan OAuth.
2.Bagaimana cara mengelola token autentikasi di Laravel?
 1.Menggunakan model HasApiTokens di model pengguna.
 2.Menggunakan metode createToken untuk menghasilkan token baru.
 3.Menyimpan token yang dihasilkan dan menggunakannya untuk otentikasi pada permintaan API.   
3.Sebutkan langkah-langkah untuk menambahkan otorisasi berbasis peran dalam API!
 1.Buat tabel roles dan role_user untuk menyimpan peran dan hubungan pengguna-peran.
 2.Tambahkan middleware untuk memeriksa peran pengguna.
 3.Terapkan middleware di rute atau kontroler yang memerlukan otorisasi peran tertentu.
 4.Sesuaikan logika kontroler untuk memeriksa peran saat mengakses resource tertentu. 
